package day5;

import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import java.util.*;

class StudentFresh{
	int rollNo;
	String name;
	String dept;
	int marks;
	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	public StudentFresh(int rollNo, String name, String dept, int marks) {
		super();
		this.rollNo = rollNo;
		this.name = name;
		this.dept = dept;
		this.marks = marks;
	}
	@Override
	public int hashCode() {
		return Objects.hash(dept, Integer.valueOf(marks), name, Integer.valueOf(rollNo));
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StudentFresh other = (StudentFresh) obj;
		return Objects.equals(dept, other.dept) && marks == other.marks && Objects.equals(name, other.name)
				&& rollNo == other.rollNo;
	}
	
}
public class StreamAPI {
public static void main(String[] args) {
	StudentFresh s1 = new StudentFresh(1,"Kushagra","CS",90);
	StudentFresh s2 = new StudentFresh(2,"Aadi","DS",89);
	StudentFresh s3 = new StudentFresh(3,"Hariom","CS",60);
	ArrayList<StudentFresh> list = new ArrayList<StudentFresh>();
	list.add(s1);
	list.add(s2);
	list.add(s3);
	
	//FILTER  ON THE BAISS OF NAME STARTS 'Y' OR 'A'
	System.out.println("FILTER NAME STARTS WITH Y OR A");
	
	@SuppressWarnings("unused")
	List<StudentFresh>filterList = list.stream().filter(s->(s.getName().startsWith("A")||s.getName().startsWith("Y"))).collect(Collectors.toList());
//	filterList.add(new StudentFresh(5,"Palak","MECH",50));
	
	for(StudentFresh data : filterList){
		System.out.println(data.name+":"+data.rollNo+" ");
	}
	//For EACH Loop
	
	System.out.println("\nFOR EACH PRACTICE***");
	list.stream().forEach(s->System.out.println(s.rollNo+":"+s.name));
	System.out.println();
	
	//Sort
	System.out.println("\nSORT PRACTICE***");
	list.stream().sorted(Comparator.comparing(StudentFresh::getMarks)).forEach(s->System.out.println(s.name+":"+s.marks));
	
	System.out.println("\nSORT ON Name DESC using compareTo***");
	list.stream().sorted((a,b)->b.getName().compareTo(a.getName())).forEach(s->System.out.println(s.name));
	
	//sort comparator marks asc using compare to
	list.stream().sorted((a,b)->a.marks-b.marks).forEach(s->System.out.println(s.marks));
	
	Integer num = 10;
	int num2=num.intValue();
	System.out.println("MARKS TOTAL**");
	
	int sum = list.stream().map(StudentFresh::getMarks).mapToInt(Integer::intValue).sum();
	System.out.println(sum);
	
	System.out.println("MAXIMUM MARKS-1");
	OptionalInt max3 = list.stream().map(StudentFresh::getMarks).mapToInt(Integer::intValue).max();
	System.out.println(max3.getAsInt());
	
	System.out.println("MAXIMUM MARKS-2");
	Optional max = list.stream().map(StudentFresh::getMarks).reduce(Integer::max);
	System.out.println(max3.getAsInt());
	
	System.out.println("MAXIMUM MARKS-NAME");
	Optional<StudentFresh> max2=list.stream().max((a,b)->Integer.compare(a.getMarks(),b.getMarks()));
	max2.ifPresent(s->System.out.println(s.name));
	
	System.out.println("GREATER THAN 70 FIRST");
	Optional<StudentFresh> opt1 = list.stream().filter(s->s.marks>70).findFirst();
	System.out.println(opt1.get().name);
	
//	HashMap<String,Optional<StudentFresh>>groupList = (HashMap<String, Optional<StudentFresh>>) list.stream().collect(Collectors.groupingBy(StudentFresh::getDept,Collectors.maxBy((a,b)->a.getMarks()-b.getMarks()));
//	
//	for(HashMap.Entry<String,Optional<StudentFresh>>e:groupList.entrySet()) {
//		System.out.println(e.getKey()+":"+e.getValue().get().marks);
//	}
//	
	System.out.println("LIMIT***");
	list.stream().limit(3).forEach(s->System.out.println(s.name));
	System.out.println("DISTINCT***");
	list.stream().distinct().forEach(s->System.out.println(s.name));
	System.out.println("SKIP***");
	list.stream().skip(1).forEach(s->System.out.println(s.name));
	
	System.out.println("FIBONAACCI");
	//0 1 1
	Stream.iterate(new int[] {0,1},arr-> new int[] {arr[1],arr[1]+arr[0]}).limit(10).forEach(s->System.out.print(s[0]+" "));
	
	//BOXED INT STREAM TO STREAM<INTEGER>
	System.out.println("\n BOXED INT STREAM TO STREAM<INTEGER>");
	List<Integer>list2 = IntStream.range(1, 10).boxed().collect(Collectors.toList());
	list2.forEach(s->System.out.print(s+" "));
	
	//RANDOM NUMBER
		System.out.println("\n RANDOM NUMBER");
		Stream<Double>randomList = Stream.generate(Math::random).limit(5);
		randomList.forEach(s->System.out.println(s+" "));
		
	//ARRAY AS LIST TO FLATMAP
		List<String>listStr = Arrays.asList("hello","how","are","you","all");
		List<String>output =listStr.stream().flatMap(s->Arrays.stream(s.split(""))).collect(Collectors.toList());
		output.forEach(s->System.out.print(s+":"));
		
	//SORT ON BASIS OF LENGTH
		System.out.println("SORT ON BASIS OF LENGTH");
		List<String>listStr2 = Arrays.asList("helloo","a","them","no","yes");
		listStr2.stream().sorted(Comparator.comparingInt(String::length)).forEach(s->System.out.print(s+" "));
		
	//sort part2
		String str = "i want new telephone today at home";
		String[]words = str.split("\s");
		List<String>listStr3 = Arrays.asList(words);
		listStr2.stream().sorted(Comparator.comparingInt(String::length)).forEach(s->System.out.print(s+" "));
		
		System.out.println();
		//sort part 3 based on length of string
		Collections.sort(listStr3,(a,b)->a.length()-b.length());
		System.out.println(listStr3);
}

}
