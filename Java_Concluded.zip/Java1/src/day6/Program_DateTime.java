package day6;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Program_DateTime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
		LocalDateTime today = LocalDateTime.parse("08/06/2026 14:08:00",formatter);
		System.out.println(today);
		System.out.println(today.getDayOfWeek());

	}

}
