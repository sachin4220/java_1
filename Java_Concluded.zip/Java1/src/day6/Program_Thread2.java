package day6;

//Thread implementation using runnable interface
class MyThreadB implements Runnable{
	public void run() {
		System.out.println(Thread.currentThread().getId());
	}
}

public class Program_Thread2 {
public static void main(String[] args) {
	for(int i=0;i<5;i++) {
		MyThreadB t2 = new MyThreadB();
		Thread thread = new Thread(t2);
		thread.start();
		
	}
	
}

}
