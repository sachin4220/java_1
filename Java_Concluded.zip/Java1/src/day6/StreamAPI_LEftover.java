package day6;

public class StreamAPI_LEftover {
	public static void main(String[] args) {
		
	}
}
