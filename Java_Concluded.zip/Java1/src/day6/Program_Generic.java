package day6;

class Demo2<T>{
	public void printData(T value) {
		System.out.println(value);
	}
}

public class Program_Generic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo2<String> obj1 = new Demo2<String>();
		obj1.printData("hello");
		
		Demo2<Integer> obj2 = new Demo2<Integer>();
		obj2.printData(10);
		
		Demo2<Boolean> obj3 = new Demo2<Boolean>();
		obj3.printData(false);

	}

}
