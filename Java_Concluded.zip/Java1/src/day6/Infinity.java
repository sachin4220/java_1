package day6;

public class Infinity {
public static void main(String[] args) {
	double num = 10.0/0;
	double infinityValue = Double.POSITIVE_INFINITY;
	System.out.println(infinityValue);
}
}
