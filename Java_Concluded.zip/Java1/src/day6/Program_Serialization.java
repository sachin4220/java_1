package day6;
import java.io.*;

class User implements Serializable{
	String username;
	transient String password;
	public User(String username , String password) {
		super();
		this.username = username;
		this.password = password;
	}
}
public class Program_Serialization {
public static void main(String[] args)throws Exception {
	User user = new User("Rahul","pass@1234");
	File file = new File("C:\\Users\\Sachin.7.Yadav\\Desktop\\FileReading.txt");
	
	FileOutputStream fos = new FileOutputStream(file);
	ObjectOutputStream oos = new ObjectOutputStream(fos);
	oos.writeObject(user);
    }
}
