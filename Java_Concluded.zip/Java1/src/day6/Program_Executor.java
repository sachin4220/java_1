package day6;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Program_Executor {
public static void main(String[] args) {
	ExecutorService executor = Executors.newFixedThreadPool(3);
	
	for(int i=1;i<=5;i++) {
		executor.submit(new MyThreadB());
	}
	executor.shutdown();
	
	
}
}
