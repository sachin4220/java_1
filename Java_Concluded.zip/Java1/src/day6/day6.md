1. Strreamapi leftover
2. enum
3. infinity check
4. serialization
5. deserializable
6. multithreading - terms are demonthread , thread
7. join in thread
8. Executor service - another way to crsate fix number of threads