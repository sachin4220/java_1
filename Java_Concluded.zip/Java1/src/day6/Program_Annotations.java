package day6;

import java.lang.annotation.*;

@interface coforge{
	String batchCode() default "2026";
}
class Demo{
	protected static String demoId;
	@coforge(batchCode="June 2026")
	void printData() {
		System.out.println(batchCode);
	}
}



public class Program_Annotations {
public static void main(String[] args) {
	
}
}
