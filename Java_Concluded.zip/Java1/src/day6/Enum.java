package day6;

enum Courses{
	Java,
	Selenium,
	C,
	Mainframe
	}
class Student12{
	String name;
	int marks;
	Courses course;
	public Student12(String name, int marks,Courses course) {
		super();
		this.name = name;
		this.marks = marks;
		this.course = course;
	}
	
	
}

public class Enum {
	public static void main(String[] args) {
		Student12 obj = new Student12("Kushagra",89,Courses.Java);
		System.out.println(obj.name+" : "+obj.course);
	}

}
