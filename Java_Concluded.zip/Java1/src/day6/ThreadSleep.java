package day6;

public class ThreadSleep {
public static void main(String[] args) throws Exception {
	System.out.println("one");
	Thread.sleep(2000);
	System.out.println("two");
	
}
}