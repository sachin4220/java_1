package day6;

//Thread is implemented using Thread class
class MyThreadA extends Thread{
	public void run() {
		System.out.println(Thread.currentThread().getName());
//		System.out.println(Thread.currentThread().getPriority());
	}
}

public class Program_Thread {
public static void main(String[] args) {
	for(int i=0;i<5;i++) {
		MyThreadA t1 = new MyThreadA();
		t1.start();
	}
	
}

}
