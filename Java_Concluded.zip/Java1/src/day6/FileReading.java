package day6;
import java.io.*;

public class FileReading {
public static void main(String[] args) {
	File file = new File("C:\\Users\\Sachin.7.Yadav\\Desktop\\FileReading.txt");
	
//	try(FileReader fr = new FileReader(file)){
//		BufferedReader br = new BufferedReader(fr);
//		String str;
//		while((str=br.readLine())!=null) {
//			System.out.println(str);
//			
//		}
//	}
//		catch(Exception ex) {
//			System.out.println(ex.getMessage());
//		}
//			
	try(FileWriter fr = new FileWriter(file)){
		fr.write("\nFive");
		System.out.println("File Writing done as sucsesfully ✅ ");
		
	}
	catch(Exception ex) {
		System.out.println(ex.getMessage());
	}
			
		
			
			
	
}
}

