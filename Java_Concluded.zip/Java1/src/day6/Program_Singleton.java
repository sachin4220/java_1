package day6;

class UserK{
	static UserK obj;
	
	private UserK() { //constructor private
		
	}
	static UserK getObj() {
		if(obj==null) 
			obj = new UserK();
			return obj;
}

public class Program_Singleton {
	public static void main(String[] args) {
		UserK a = new UserK().getObj();
		UserK b = new UserK().getObj();
		if(a==b) {
			System.out.println("Same Object");
		}
	}
}

}
