package day6;

import java.io.*;

public class Deserializable {

	public static void main(String[] args) throws Exception {
		File file =new File ("C:\\Users\\Sachin.7.Yadav\\Desktop\\FileReading.txt");
		
		FileInputStream fis = new FileInputStream(file);
		ObjectInputStream ois=new ObjectInputStream(fis);
		User obj=(User)ois.readObject();
		System.out.println(obj.username+" : "+ obj.password);
		// TODO Auto-generated method stub

	}

}
