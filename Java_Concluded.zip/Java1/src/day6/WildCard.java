package day6;

import java.util.Arrays;
import java.util.List;

class Demo3<T>{
	public void printData(T value) {
		System.out.println(value);
	}
}

public class WildCard {
	public static void printFirst(List<?>list) {
		System.out.println(list);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		printFirst(Arrays.asList(1,2,3,4));
		printFirst(Arrays.asList("hello","Kushagra"));
		printFirst(Arrays.asList(1.0,2.0,3.0));
		
		
		
//		Demo2<String> obj1 = new Demo2<String>();
//		obj1.printData("hello");
//		
//		Demo2<Integer> obj2 = new Demo2<Integer>();
//		obj2.printData(10);
//		
//		Demo2<Boolean> obj3 = new Demo2<Boolean>();
//		obj3.printData(false);

	}

}
