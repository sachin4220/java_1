package Selenium_Day1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Program3_FormHandling {
public static void main(String[] args)throws Exception {
	ChromeDriver driver = new ChromeDriver();
	Thread.sleep(2000);
	driver.manage().window().maximize();
	Thread.sleep(2000);
	driver.get("https://engineerdiaries.com/selenium");
	Thread.sleep(5000);
	List<WebElement>boxes = driver.findElements(By.name("programmingLang"));
	boxes.get(0).click();
	List<WebElement>boxes1 = driver.findElements(By.name("gender"));
	boxes1.get(1).click();
	WebElement inputBox=driver.findElement(By.id("input_text"));
	inputBox.clear();
	Thread.sleep(2000);
	inputBox.sendKeys("JAVA");
	driver.findElement(By.tagName("textarea")).sendKeys("Tester Kushagra it is working fine");
	
	Thread.sleep(2000);
}
}
