package Selenium_Day4;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

public class Program_Scroll {
public static void main(String[] args)throws Exception {
	ChromeDriver driver = new ChromeDriver();
	Thread.sleep(3000);
	driver.get("https://www.engineerdiaries.com/selenium");
	Thread.sleep(3000);
	JavascriptExecutor js = driver;
	js.executeScript("window.scrollTo(0,document.body.scrollHeight);");
	js.executeScript("document.getElementById('input_text').value='hello'");
}
}
