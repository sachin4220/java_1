package Selenium_Day4;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;

public class Program_Wait {
public static void main(String[] args) throws Exception{
	ChromeDriver driver =new ChromeDriver();
//	driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(1));
	driver.get("https://www.engineerdiaries.com/selenium");
	Thread.sleep(3000);
	//Implicit Wait Syntax
	
//	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(25));
	driver.findElement(By.id("input_text")).sendKeys("Hello bhai chl rha hu");
//	inputBox.clear();
	
	
	//Explicit Wait Syntax
//	WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(15));
//	
//	wait.until(ExpectedConditions.presenceOfElementLocated(By.id("input_text"))).sendKeys("Hello");
	
	
	}
}
