package Selenium_Day4;

import java.util.HashMap;
import java.util.Map;

//import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Program_HeadlessMode {
public static void main(String[] args)throws Exception {
	ChromeOptions opt = new ChromeOptions();
	opt.addArguments("--headless");
	
	Map<String,Object> prefs = new HashMap<>();
//	prefs.put("profile.default_content_setting_values.geolocation",2);
	opt.setExperimentalOption("prefs", prefs);
	ChromeDriver driver = new ChromeDriver(opt);
	driver.manage().window().maximize();
	driver.get("https://geeksforgeeks.com/");
	System.out.println(driver.getTitle());
	Thread.sleep(2000);
	driver.quit();
	
//	driver.findElement(By.linkText("Contact Us")).click();
//	Thread.sleep(3000);
//	driver.navigate().back();
	
	//Partial Link Text
//	driver.findElement(By.partialLinkText("Contact")).click();
}
}
