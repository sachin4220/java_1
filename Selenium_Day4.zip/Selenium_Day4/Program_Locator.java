package Selenium_Day4;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class Program_Locator {
	public static void main(String[] args)throws Exception {
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://engineerdiaries.com/");
		driver.manage().window().maximize();
		Thread.sleep(3000);
		
		driver.findElement(By.linkText("Contact Us")).click();
		Thread.sleep(3000);
		driver.navigate().back();
		
		//Partial Link Text
		driver.findElement(By.partialLinkText("Contact")).click();
	}

}
