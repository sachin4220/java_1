package june2026.coforgejune26;


import org.testng.annotations.*;

public class MobileTest {
	
	@Test
	void mobile() {
		System.out.println("MOBILE");
	}

}
