package june2026.coforgejune26;


import org.testng.annotations.*;

public class LoginTest {
	
	@Test
	void login() {
		System.out.println("LOGIN");
	}

}
