package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PracticePage {
	WebDriver driver;
	By inputBox = By.id("input_text");
	By textareaBox = By.tagName("textarea");
	public PracticePage(WebDriver driver){
		this.driver=driver;
	}
	public WebDriver getDriver() {
		return driver;
	}
	public WebElement getInputBox() {
		return this.driver.findElement(inputBox);
	}
	public WebElement getTextareaBox() {
		return this.driver.findElement(textareaBox);
	}

}
