package june2026.coforgejune26;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import pageObjects.PracticePage;

public class Selenium_Page {
	public static void main(String[] args)throws Exception {
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://engineerdiaries.com/selenium");
		Thread.sleep(3000);
		driver.findElement(By.id("input_text")).sendKeys("Java");
		Thread.sleep(2000);
		PracticePage practice = new PracticePage(driver);
		practice.getInputBox().sendKeys("JAVA");
		Thread.sleep(3000);
//		practice.getTextareaBox().sendKeys("Haa Bhai Kya haal Chaal");
	}
	
	//test ng -> listenr include exclue groups data provider parameter , maven architecture , lifecycle ,dependency add , rpoject sstructure profile switching , log4j2 api core , 4 logs error info fatal debug , excel reading , wrtiitng excel , page object structrue , selenium page

}
