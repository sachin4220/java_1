package june2026.coforgejune26;

import java.io.FileInputStream;
import java.util.Iterator;

import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {
	public static void main(String[] args)throws Exception {
		FileInputStream file = new FileInputStream("C:\\Users\\Sachin.7.Yadav\\eclipse-workspace\\coforgejune26\\src\\main\\resources\\ReadFile.xlsx");
		XSSFWorkbook book = new XSSFWorkbook(file);
		XSSFSheet sheet = book.getSheetAt(0);
		Iterator<Row>rows = sheet.iterator();
		while(rows.hasNext()) {
			Row row =  rows.next();
			Iterator<Cell>cols = row.cellIterator();
			while(cols.hasNext()) {
				Cell value = cols.next();
					if(value.getCellType()==CellType.NUMERIC) {
						System.out.println((int)value.getNumericCellValue()+" ");
					}
					else {
						System.out.println(value+" ");
					}
			}
		System.out.println();
		}
		
	}
}
