package june2026.coforgejune26;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class WriteExcel {
	public static void main(String[] args)throws Exception {
		FileInputStream file = new FileInputStream("C:\\Users\\Sachin.7.Yadav\\eclipse-workspace\\coforgejune26\\src\\main\\resources\\ReadFile.xlsx");
		XSSFWorkbook book = new XSSFWorkbook(file);
		Sheet sheet = book.getSheetAt(0);
		Row row = sheet.createRow(5);
		row.createCell(0).setCellValue(4);
		row.createCell(1).setCellValue("Kushagra");
		Row row1 = sheet.createRow(6);
		row1.createCell(0).setCellValue(5);
		row1.createCell(1).setCellValue("Aadi");
		
		//Write to file
		FileOutputStream fos = new FileOutputStream("C:\\Users\\Sachin.7.Yadav\\eclipse-workspace\\coforgejune26\\src\\main\\resources\\ReadFile.xlsx");
		book.write(fos);
		fos.close();
	}

}
