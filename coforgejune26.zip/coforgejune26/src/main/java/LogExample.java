import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

public class LogExample{
	static final Logger logger = LogManager.getLogger(LogExample.class.getName());

	public static void main(String[] args) {
		 
		 
		  	logger.info("INFO");
		  	logger.error("ERROR");
		    logger.debug("DEBUG");
		    logger.fatal("FATAL**");
		    
		  
	}
}

