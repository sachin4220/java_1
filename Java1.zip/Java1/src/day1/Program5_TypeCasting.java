package day1;

public class Program5_TypeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 10;
		float marks = num;
		System.out.println(marks);
		
		int data = 100;
		long phone = data;
		System.out.println(phone);
		
		float num1 = 1.2f;
		int num2 = (int)num1;
		System.out.println(num2);
		
		//byte>short>int>long>float>double
		//|
//		  char>int>long>float>double
	}

}
