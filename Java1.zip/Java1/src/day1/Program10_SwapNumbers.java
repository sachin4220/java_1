package day1;

public class Program10_SwapNumbers {

	public static void main(String[] args) {
		// using temp swapping
		int a = 10;
		int b=20;
		
//		int temp = a;
//		a = b;
//		b = temp;
//		System.out.println("after swap A  : "+a+"After swap B : "+b);
		
		
//		//using swap without temp
//		a=a+b;
//		b=a-b;
//		a=a-b;
//		System.out.println("after swap A  : "+a+"After swap B : "+b);
		
		//using xor
		a=a^b;  //
		b=b^a;
		a=a^b;
		System.out.println("after swap A  : "+a+" After swap B : "+b);
		
		
		

	}

}
