package day1;

import java.util.Scanner;

public class Program12_Loops {

	public static void main(String[] args) {
//		?Scanner sc = new Scanner(System.in);
//	int n = sc.nextInt();
//		sum(n);
//		System.out.println(factorial(n));
//		sumofDigit(n);
//		prime(n);
		
//		System.out.println("Hello");
//		
//		for(int i=1;i<=10;i++) {
//			System.out.print(i+" ");
//			if(i==5)break;
//			
//		}
//		System.out.println();
//		System.out.println("Bye");
//		System.out.println();
//		
//		System.out.println("Hello");
//		int i=1;
//		while(i<=10) {
//			System.out.print(i+" ");
//			if(i==5)break;
//			i++;
//			
//
//		}
//		System.out.println();
//		System.out.println("Bye");
		System.out.println("Hello");
		for(int i=1;i<=10;i++) {
			if(i==5)continue;
			System.out.print(i+" ");
		}
		System.out.println("\nBye\n");
	
		System.out.println("Hello");
		int i=1;
		while(i<=10) {
			if(i==5) {
				i++;
			}
			System.out.print(i+" ");
			i++;
		}
		System.out.println("\nBye");
	
	}
	public static void sum(int n) {
		int sum = 0;
		for(int i=1;i<=n;i++) {
			sum+=i;
		}
		System.out.println(sum);
	}
	public static int factorial(int n) {
		if(n==1) {
			return 1;
		}
		
		return n * factorial(n-1);
	}
	public static void sumofDigit(int n) {
		int num = n;
		int sum = 0;
		while(num!=0) {
			int rem = num%10;
			sum+=rem;
			num/=10;
		}
		System.out.println(sum);
	}
	public static void prime(int n) {
		int num = n;
		int c =2;
		if(num==1) {
			System.out.println("Neither prime nor composite");
		}
		if(num==2) {
			System.out.println("Prime");
		}
	int found = 0;
		while(c*c<=num) {
			if(num%c==0) {
				System.out.println("Not Prime");
				found = 1;
				break;
			}
			
		}
		if(found==0) {
			System.out.println("Prime");
		}
		
	}
	

}
