package day1;

public class Program7_ifElse {
	public static void main(String[]args) {
		int age =18;
		if(age==18) 
			System.out.println("Congrats");
		
		
		if(age>18) {
			System.out.println("You can vote");
		}else {
			System.out.println("You cannot vote");
		}
		
	}

}
