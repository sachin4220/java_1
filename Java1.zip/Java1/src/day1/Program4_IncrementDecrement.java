package day1;

public class Program4_IncrementDecrement {

	public static void main(String[] args) {
		int num =10;
		System.out.println(num);
		System.out.println(num);
		
		
		
	}

}
