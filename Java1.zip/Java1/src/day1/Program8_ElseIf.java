package day1;

public class Program8_ElseIf {
	public static void main(String[]args) {
		char gender = 'F';
		int age =18;
		if(age==18) {
			System.out.println("Congrats on your first vote");
			if(gender=='F') {
				System.out.println("Girl");
			}else {
				System.out.println("Boy");
			}
		}
			
		if(age>=18) {
			System.out.println("You can vote");
		}
		else {
			System.out.println("You cannot vote");
		}
	}
}
