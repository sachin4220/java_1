package day1;

public class Program11_PrintPrintln {


	public static void main(String[] args) {
		float marks = 89.100F;
		System.out.print("one");
		System.out.println("two");
		System.out.println("three");
		
		  System.out.print("four \t hello \n bye");
		  System.out.printf("five %.2f",marks);
		  
		

	}

}
