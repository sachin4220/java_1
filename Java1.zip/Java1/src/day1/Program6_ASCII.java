package day1;

public class Program6_ASCII {
	public static void main(String []args) {
		char alpha = 'A';
		int num = alpha;
		System.out.println(num);
		
		
	}

}
