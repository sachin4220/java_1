package day1;

public class Program2_DataType {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num =10;
		System.out.println("Int takes 4 bytes:"+num);
		
		boolean result = false;
		System.out.println(result);
		
		long phoneNumber = 88823041908823L;
		System.out.println(phoneNumber);
		
		double dblMarks = 12.32424222;
		System.out.println(dblMarks);
		
		
	}

}
