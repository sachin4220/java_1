package day1;

public class Program9_Even {

	public static void main(String[] args) {
		int num= 10;
		int num1=0;
		if(num1==0) {
			System.out.println("Input is :"+num1);
		}
		if(num%2==0) {
			System.out.println("num is even");
		}
		else {
			System.out.println("num is odd");
		}
		
		
		// TODO Auto-generated method stub

	}

}
