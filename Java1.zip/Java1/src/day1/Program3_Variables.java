package day1;

public class Program3_Variables {

	public static void main(String[] args) {

		int num = 10;
		int %num = 10 //X cannout use percentage
		int num2 = 10;
		int 2num = 10; //X cannout use nunber starting fir a variable declaration
		
	}

}
