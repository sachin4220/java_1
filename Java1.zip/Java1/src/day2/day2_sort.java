package day2;
import java.util.*;

public class day2_sort {
	public static void main(String[] args) {
		int[]arr5={10,0,20,0,0,30};
		for(int i=0;i<arr5.length;i++) {
			for(int j=i;j<arr5.length-i-1;j++) {
				if(arr[j]>arr5[j+1]) {
					int temp = arr5[j];
					arr5[j] = arr5[j+1];
					arr5[j+1] = temp;
				}
			}
		}
		System.out.println(Arrays.toString(arr5));
	}

}
