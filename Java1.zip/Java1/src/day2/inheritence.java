package day2;

public class inheritence {

	public static void main(String[] args) {
		class parent{
			parent(){
				System.out.println("parent cons");
			}
			void print() {
				System.out.println("parent");
			}
		}
		class child extends parent{
			child(){
				System.out.println("child cons");
			}
			@override
			void print() {
				System.out.println("child");
			}
		}
		

	}

}
