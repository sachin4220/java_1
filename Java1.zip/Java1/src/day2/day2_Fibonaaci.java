package day2;

public class day2_Fibonaaci {
public static void main(String[] args) {
	int num1 =0;
	int num2=1;
	int counter =2;
	System.out.print(num1+" "+num2+" ");
	counter = 10-counter;
	
	while(counter>0) {
		int num3 = num1+num2;
		System.out.print(num3+" ");
		num1 = num2;
		num2 =num3;
		counter--;
		
	}
	fibo(7)
}
public static int fibo(int n) {
	if(n==1)return;
	
	return fibo(n-1)+fibo(n-2);
}
}
