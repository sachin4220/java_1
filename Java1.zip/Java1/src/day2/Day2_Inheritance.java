package day2;

public class Day2_Inheritance {
	public static void main(String[] args) {
		Day2_WeaponRating rating = new Day2_WeaponRating();
		rating.userId(85010215);
		rating.comment("Nice food");
		rating.rate(120.2F);
		rating.effect = true;
		rating.gender("Male");
	}
}
