package day2;

import java.util.Arrays;
import java.util.Scanner;

public class day2_Array {
	
public static void main(String[] args) {
	//Question 1
	int[]arr1 = {10,20};
	int[]arr2 = {30,40};
	
	int []arr3 = new int[arr1.length+arr2.length];
	int k=0;
	for(int i=0;i<arr1.length;i++) {
		arr3[k]=arr1[i];
		k++;
	}
	
	for(int i=0;i<arr2.length;i++) {
		arr3[k] = arr2[i];
		k++;
	}
	System.out.println("Merged Array: "+Arrays.toString(arr3));
	
	//Question 2
	int []arr = {100,20,30,99,2};
	int largest = Integer.MIN_VALUE;
	int secondLargest = Integer.MIN_VALUE;
	for(int i=0;i<arr.length;i++) {
		if(arr[i]>largest) {
			secondLargest = largest;
			largest = arr[i];
		}else if(arr[i]>secondLargest && arr[i]!=largest) {
			secondLargest = arr[i];
		}
	}
	System.out.println("Largest is :"+largest);
	System.out.println("Second Largest  is :"+secondLargest);
	
	//Question 3 : MOve all zeroes to all end
	
	int[]arr5={10,0,20,0,0,30};
	int  j = 0;
	for(int i=0;i<arr5.length;i++){
		if(arr5[i]!=0) {
			arr5[j]=arr5[i];
			
			j++;
			
		}
	}
	while(j<arr5.length) {
		arr5[j++]=0;
	}
	System.out.println("MOve zeroes to end: "+Arrays.toString(arr5));
//	for(int k=0;k<arr5.length;k++) {
//		System.out.print(arr5[k]+" ");
//	}
	
//	int[]arr5={10,0,20,0,0,30};
//	for(int i=0;i<arr5.length;i++) {
//		for(int j=i;j<arr5.length-i-1;j++) {
//			if(arr[j]>arr5[j+1]) {
//				int temp = arr5[j];
//				arr5[j] = arr5[j+1];
//				arr5[j+1] = temp;
//			}
//		}
//	}
//	System.out.println(Arrays.toString(arr5));
}
}

