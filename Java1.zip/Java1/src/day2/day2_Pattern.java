package day2;

public class day2_Pattern {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		pattern1(5);
//		pattern2(5);
		pattern3(9);
//		pattern4(9);
//		pattern5(5);
	}
	public static void pattern1(int n) {
		for(int i=0;i<n;i++) {
			for(int j=0;j<=i;j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		System.out.println();
	}
	
	public static void pattern2(int n) {
		int num = 1;
		for(int i=0;i<n;i++) {
			for(int j=0;j<=i;j++) {
				System.out.print(num+" ");
				num++;
			}
			System.out.println();
		}
		System.out.println();
	}
	
	public static void pattern3(int n) {
		for(int i=1;i<=n;i++) {
			for(int j=1;j<=n-i;j++) {
				System.out.print(" ");
			}
			for(int k=1;k<=i;k++) {
				System.out.print("*");
			}
			System.out.println();
		}
		System.out.println();

		
}
	public static void pattern4(int n) {
		for(int i=1;i<=5;i++) {
			//character
			for(int j=1;j<=i;j++) {
				System.out.print("*");
			}
			//space
			for(int j=1;j<=n-2*i;j++) {
				System.out.print(" ");
			}
			
			//character
			for(int j=1;j<=i;j++) {
				System.out.print("*");
				
			}
			System.out.println();
			
			//second half
			
		}
		for(int i=1;i<=4;i++) {
			//character
			for(int j=1;j<=5-i;j++) { 
				System.out.print("*");
			}
			//space
			for(int j=1;j<=i;j++) {
				System.out.print(" ");
			}
			//character
			for(int j=1;j<=5-i;j++) { 
				System.out.print("*");
			}
			System.out.println();
		}
		
	}

	public static void pattern5(int n) {
		for(int i = 0;i<=n;i++) {
			//space
			for(int j = 0;j<n-2*i-1;j++) {
				System.out.print(" ");
			}
			//character
			for(int j = 0;j<2*i+1;j++) {
				System.out.print("* ");
			}
			//space
			for(int j = 0;j<n-2*i-1;j++) {
				System.out.print(" ");
			}
			
			System.out.println();
		}
		
	}
}