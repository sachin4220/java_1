package day2;

public class Day2_BookRating {
	int userId;
	String comment;
	float rate;
	boolean effect;
	
	
}
