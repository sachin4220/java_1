package day2;

class Employee{
	int employeeId;
	String Name;
	int Salary;
	void print() {
		System.out.println(employeeId+":"+Name+":"+Salary+":");
	}
	Employee(int employeeId1 , String Name1, int Salary1){
		employeeId = employeeId1;
		Name=Name1;
		Salary=Salary1;
	}
	Employee(int employeeId1){
		employeeId = employeeId1;
	}
}
public class day2_Class {
	public static void main(String[] args) {
		Employee emp = new Employee(85010215,"Kushagra",20000);
//		emp.employeeId = 85010215;
//		emp.Name = "Rajat";
//		emp.Salary = 100;
		emp.print();
		
		Employee emp2 = new Employee(85010185,"Aadi",20000);
		emp2.print();
//		
		
	}
}
