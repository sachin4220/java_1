package day2;

import java.util.Scanner;

public class day2_Matrices {
	public static void main(String[] args) {
		int [][]arrA = {{10,20,30},{40,50,60},{70,80,90}};
		int [][]arrB = {{1,2,3},{4,5,6},{7,8,9}};
		int [][]arrC = new int[3][3];
		
		for(int i=0;i<arrA.length;i++) {
			for(int j=0;j<arrA[0].length;j++) {
				arrC[i][j]  = arrA[i][j] + arrB[i][j];
				System.out.print(arrC[i][j]+" ");
			}
			System.out.println();
		}
	}
}
