package day2;

public class Day2_WeaponRating extends Day2_BookRating{
	String gender;
	
public static void main(String[] args) {
	
}


}
class 
