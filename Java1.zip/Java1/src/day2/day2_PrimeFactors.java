package day2;

import java.util.ArrayList;
import java.util.List;

public class day2_PrimeFactors {
public static void main(String[] args) {
	primeFactor(29);
}

public static void primeFactor(int n) {
	List<Integer> temp = new ArrayList<>();	
	
	for(int i=2;i<=n;i++) {
	if(n%i==0) {
		if(checkPrime(i)) {
			temp.add(i);
		}
	}		
	}
	System.out.println(temp);
}
public static boolean checkPrime(int n) {
	int c = 2;
	while(c*c<=n) {
		if(n%c==0) {
			return false;
		}
		c++;
	}
	return true;
}

}
