package day2;

class Parent2
{
	String house;
	Parent2(){
		System.out.println("Parent COnstructor called");
	}
}
class Child2 extends Parent2{
	String car;
	Child2(){
		//super();
		this("Creta");
		System.out.println("Child COstructor called");
	}
	Child2(String car){
		this.car = car;
		System.out.println("One parameter called");
	}
	Child2(String house , String car){
		this.house = house;
		this.car = car;
		
	}
}





class Student{
	int rollNo;
	String name;
	Student(int rollNo, String name){
		this.rollNo = rollNo;
		this.name=name;
		System.out.println("Parameterised constructor called");
	}
	Student(){
		this(-1,"Kushagra");
		System.out.println("Default constructor called");
	}
}


public class Day2_This {
public static void main(String[] args) {
//	Student s1 = new Student(12,"Kyshagra");
//	Student s1 = new Student();
	Child2 c1  = new Child2();
}

}
