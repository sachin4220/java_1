package day2;

public class day2_Methods {
	
	static void sum(int num1,int num2) {
		int total = num1+num2;
		System.out.println(total);
	}
	static int diff(int num1,int num2) {
		int diff = num1-num2;
		return diff;
	}
	
	
	
	
public static void main(String[] args) {
	sum(10,20);
	System.out.println(diff(29,13));
}
}
