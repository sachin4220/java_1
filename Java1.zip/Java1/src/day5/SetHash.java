package day5;

import java.util.HashSet;
import java.util.Objects;

class Student{
	int rollNo;
	String name;
	public Student(int rollNo, String name) {
		super();
		this.rollNo = rollNo;
		this.name = name;
	}
	@Override
	public int hashCode() {
		return Objects.hash(name, Integer.valueOf(rollNo));
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		return Objects.equals(name, other.name) && rollNo == other.rollNo;
	}
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}
}

public class SetHash {
public static void main(String[] args) {
	HashSet<Student> s1 = new HashSet<Student>();
	Student s3 = new Student(101,"Kushagra");
	Student s2 = new Student(101,"Kushagra");
	s1.add(s2);
	s1.add(s3);
	for(Student s:s1) {
		System.out.println(s.rollNo+":"+s.name);
	}
	
	
}
}
