package day5;


interface IUser{
//	void print(String name);
	String print(String name);
}

public class FunctionalINterface {
public static void main(String[] args) {
	IUser user = (value)->{
		return("Hello!"+value);
	};
	String output = user.print("Java");
	System.out.println(output);
	
}
}
