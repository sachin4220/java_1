package day5;
import java.util.*;
public class Set2 {
	public static void main(String[] args) {
		LinkedHashSet<String> set = new LinkedHashSet<String>();
		
		String s1 = "The day today is a very very very warm day";
		
		
		for(String word : s1.split(" ")) {
			set.add(word);
		}
		System.out.println(set);
	}
}
