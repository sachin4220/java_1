package day5;

import java.util.*;
import java.util.Map.*;
public class Map {
public static void main(String[] args) {
	HashMap<Integer,String> map = new HashMap<>();
	map.put(1, "Kushagra");
			map.put(2, "Kushagra");
			map.put(3, "Aadi");
	for(Entry<Integer,String>e:map.entrySet()) {
		System.out.println(e.getKey()+":"+e.getValue());
	}
	System.out.println(map.get(3));
	System.out.println(map.containsKey(7));
}
}
