package day5;

import java.util.HashMap;

public class MapQ1 {
public static void main(String[] args) {
//	String s ="aaabbc";
//	HashMap<Character,Integer> map = new HashMap<>();
//	for(int i=0;i<s.length();i++) {
//		map.put(s.charAt(i),map.getOrDefault(s.charAt(i),0)+1);
//	}
//	System.out.println(map);
//	for(Character ch : map.keySet()) {
//		System.out.print(ch+""+map.get(ch));
//	}
	String s2 = "The day today is a very very warm day";
	String[]words = s2.split(" ");
	HashMap<String , Integer> map2 = new HashMap<>();
	for(int i=0;i<words.length;i++) {
		map2.put(words[i],map2.getOrDefault(words[i],0)+1);
	}
	for(String ch : map2.keySet()) {
		System.out.println(ch+" : "+map2.get(ch));
	}
	
}

}
