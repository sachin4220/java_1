package day5;

import java.util.HashSet;

public class Venn {
public static void main(String[] args) {
	HashSet<Integer> setA = new HashSet<Integer>();
	setA.add(10);
	setA.add(20);
	setA.add(30);
	
	HashSet<Integer> setB = new HashSet<Integer>();
	setB.add(40);
	setB.add(50);
	setB.add(60);
	
	HashSet<Integer> union = new HashSet<Integer>();
	union.addAll(setB);
	System.out.println("Union : "+union);
	

	HashSet<Integer> intersection = new HashSet<Integer>();
	intersection.retainAll(setB);
	System.out.println("Intersection : "+intersection);
	
	HashSet<Integer>diff = new HashSet<Integer>(setA);
	diff.removeAll(setB);
	System.out.println("Difference : "+diff);
	
	
}


}
