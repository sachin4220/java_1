package day5;
import java.util.*;

public class Set {
public static void main(String[] args) {
	HashSet<Integer> s1 = new HashSet<Integer>();
	s1.add(1);
	s1.add(2);
	s1.add(2);
	Iterator<Integer> it= s1.iterator();
	while(it.hasNext()) {
		System.out.println(it.next()+"");
	}
}
}
