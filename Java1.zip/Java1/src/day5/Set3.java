package day5;
import java.util.*;
public class Set3 {
	public static void main(String[] args) {
		ArrayList<Integer>l1 = new ArrayList<Integer>();
		l1.add(10);
		l1.add(20);
		l1.add(30);
		l1.add(20);
		l1.add(10);
		LinkedHashSet<Integer> set = new LinkedHashSet<>();
		for(int num : l1) {
			set.add(num);
			
		}
		System.out.println(set);
	}
}
