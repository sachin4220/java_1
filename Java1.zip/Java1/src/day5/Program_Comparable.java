package day5;

import java.util.Collections;
import java.util.List;
import java.util.*;

class Employee implements Comparable<Employee>{
	int empId;
	String name;
	
	public Employee(int empId, String name) {
		super();
		this.empId = empId;
		this.name = name;
	}
	public int compareTo(Employee o) {
//		return this.empId-o.empId;
		return o.name.compareTo(this.name);
	}
}

class EmployeeComparator implements Comparator<Employee>{
	public int compare(Employee o1,Employee o2) {
		return o2.empId-o1.empId;
	}
}



public class Program_Comparable {
	public static void main(String[] args) {
		Employee e1 = new Employee(3,"Aadi");
		Employee e2 = new Employee(2,"Hariom");
		Employee e3 = new Employee(1,"Kushagra");
		
		List<Employee> list = new ArrayList<Employee>();
		list.add(e1);list.add(e2);list.add(e3);
		Collections.sort(list  , new EmployeeComparator());
		for(Employee e:list) {
			System.out.println(e.empId+":"+e.name);
		}
	}

}
