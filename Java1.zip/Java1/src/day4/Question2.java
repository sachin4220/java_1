package day4;

import java.util.Stack;

public class Question2 {
public static void main(String[] args) {
	String str = "((())";
	Stack<Character> s1 = new Stack<Character>();
	int j = 0;
	while(j<str.length()) {
		s1.push(charAt(j));
	}
	int i = 0;
	int cnt = 0;
	boolean flag = false;
	if(s1.isEmpty()) flag =  true;
	while(!s1.isEmpty()) {
		if(s1.peek() == '(') cnt++;
		else {
			cnt--;
		}
	}
	if(cnt != 0) flag = false;
	return true;
}
}
