package day4;

import java.util.ArrayList;
import java.util.List;

class Student{
	private int rollNo;
	private String name;
	
	Student(int rollNo, String name){
		this.rollNo = rollNo;
		this.name = name;
	}
	
	public void printData() {
		System.out.println(rollNo+": "+name+" ");
	}
}

public class Question {
public static void main(String[] args) {
	List<Student> s1 = new ArrayList<>();
	s1.add(new Student(101,"Kushagra"));
	s1.add(new Student(102,"Aadi"));
	s1.add(new Student(103,"Hariom"));
	
	for(Student s:s1) {
		s.printData();
	}
	
}
}
