package day4;
import java.util.*;
public class listJava {
	public static void main(String[] args) {
		List<Integer>list=new ArrayList<Integer>();
		list.add(10);
		list.add(20);
		list.add(30);
		System.out.println(list);
		for(Integer num:list) {
			System.out.println(num+" ");
		}
		System.out.println("\noth element:"+list.get(0));
		System.out.println("Contains 40:"+ list.contains(40));
		System.out.println("Index of 10"+ list.indexOf(10));
		list.remove(0);
		System.out.println(list);
		list.set(0, 100);
		System.out.println(list);
		List<Integer> l2 = new ArrayList<>();
		l2.add(22);
		l2.add(44);
		
		list.addAll(l2);
		System.out.println(list);
		// TODO Auto-generated method stub
		Iterator<Integer> it = list.iterator();
		while(it.hasNext()) {
			System.out.println(it.next()+"");
		}
		System.out.println();
		
		ListIterator<Integer> lit = list.listIterator();
		
			System.out.println(lit.next()+"");
			System.out.println(lit.previous());
		System.out.println();	

	}

}
