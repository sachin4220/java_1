package day4;

interface ITest{
	public static final int num1=10;
	int num2=20;
	void hello();
	public astract void bye();
	default void printData() {
		System.out.println("PRINT DATA");
	}
	static void printData2() {
		System.out.println("PRINT DATA 2");
	}
}
class TestB implements ITest{
	public void hello() {
		System.out.println();
	}
	public void bye() {
		System.out.println();
	}
	
}
public class Interfaces {
public static void main(String[] args) {
	ITest obj = new ITest();
}
}
