package day4;
interface ITestA{
	int num =10;
	void hello();
	void bye();
	
}
interface ITestB{
	int num = 20;
	void hello();
	int bye();
}
class TestC implements ITestA,ITestB{
	public void bye() {
		
	}
	public int bye() {
		return 10;
	}
	
	
	public void hello() {
		System.out.println("Hello:"+num);
	}
}

public class MultipleInheritance {
public static void main(String[] args) {
	
}
}
