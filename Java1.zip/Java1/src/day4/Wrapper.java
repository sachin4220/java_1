package day4;

public class Wrapper {
public static void main(String[] args) {
	int num = 10;
	//Autoboxing
	Integer data = num;
	
	//Unboxing
	Integer num2=10;
	int data2=num2;
}
}
