package day4;
import java.util.*;

public class regEx {

	public static void main(String[] args) {
//		String prCode1= "amazon349";
//		String regex1= "^amazon[0-6]{3}$";
//		System.out.println("Output1:" +prCode1.matches(regex1));
//		String prCode2= "Aadiamazon346Kushaga";
//		String regex2= ".*amazon[0-6]{2,3}.*";
//		System.out.println("Output2:" +prCode2.matches(regex2));
//		String email= "aBCDEFG100@infosys.com";
//		String regex3= "^[A-Za-z]{3,7}_?[0-9]{2,3}@infosys.com$";
//		System.out.println("Output2:" +email.matches(regex3));
		// TODO Auto-generated method stub
//		StringBuilder sb = new StringBuilder();
		String[]words = {"today","is","friday"};
		for(int i=0;i<words.length;i++) {
			StringBuilder sb = new StringBuilder(words[i]);
			sb.reverse();
			words[i]=sb.toString();
		}
		System.out.println(Arrays.toString(words));
	}

}
