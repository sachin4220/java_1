package day4;

abstract class Test{
	abstract void hello();
	void bye() {
		System.out.println("Bye");
	}
}
class TestA extends Test{
	void hello() {
		System.out.println("Hello");
	}
}

public class Abtsract {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
