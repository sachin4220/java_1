package day3;


class TestData{
	statci int num1;
	int num2;
	static {
		System.out.println("static block called");
	}
	void hello() {
		System.out.println()
	}
}
	

public class Static {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
