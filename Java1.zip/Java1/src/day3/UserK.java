package day3;

public class UserK {
	
	String name;int age;
	 class Address{
		String city;
		String state;
		String country;
	}
	 static class Favorite{
		 String color;
		 String food;
		  static string car;
	 }
}
