package day3;

class Student{
	String name;
	int marks;
	
//	Student(){
//		System.out.println("Default Constructor 1 called after this()");
//	}
	Student(String name , int marks){
		
		this.name = name;
		this.marks = marks;
		System.out.println("Parameterised Constructor");
	}
}
class EngineeringStudent extends Student{
	String course = "Btech";
	void printData() {
		System.out.println(this.name+":"+this.marks+":"+this.course+":");
		if(super.marks>9) {
			System.out.println("Try to improve");
		}
		System.out.println(this.name+":"+this.marks+":"+this.course+":");
	}
	EngineeringStudent(String name , int marks){
		super(name, marks);
		
		System.out.println("Engineering Student Default constructor called");
	}
}

public class This {
public static void main(String[] args) {
//	Student s1 = new Student();
//	Student s2=  new Student("AAdi",80);
	EngineeringStudent s1 = new EngineeringStudent("Kushagra",80);
//	System.out.println("This name : "+s2.name);
//	System.out.println("This marks : "+s2.marks);
//	s1.name = "Kushagra";
//	s1.marks = 80;
	System.out.println();
}
}
