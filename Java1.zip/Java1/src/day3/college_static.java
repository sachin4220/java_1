package day3;


class Testdata{
	static int num1;
	int num2;
	static {
		System.out.println("Static block called of test data"+);
	}
}
public class college_static {
	static {
		System.out.println("Static block of college sratic called");
	}

	public static void main(String[] args) {
		Testdata.num1=10;
		

	}

}
