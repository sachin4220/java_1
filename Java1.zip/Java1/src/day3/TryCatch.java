package day3;

public class TryCatch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[]arr = {19,20};
		try {
			System.out.println("Hello");
			Thread.sleep(1000);
			int n = arr[3];
			System.out.println("Bye");
			
		}catch(Exception e) {
			System.out.println(e.getMessage());
			System.exit(0);
		}
		
		finally {
			System.out.println("Bye");
		}
	
		
		
	}

}
