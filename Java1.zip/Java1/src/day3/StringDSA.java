package day3;
import java.util.*;
public class StringDSA {
public static void main(String[] args) {
	
//	//Question 1 : JAVA1234KK4
//		String s  ="JAVA1234KK4";
//		int sum = 0;
//		for(int i=0;i<s.length();i++) {
//			System.out.print(s.charAt(i)+" ");
//			char data = s.charAt(i);
//			if(Character.isDigit(data)) {
//				sum+=data-'0';
//			
//			}else {
//				continue;
//			}
//		}
//		System.out.println(sum);
//		
//		//Question 2 : JAVA1234KK4
//		String s1  ="JAVA1234KK4";
//		for(int i=0;i<s1.length();i++) {
//			char data = s1.charAt(i)
//		}
	
//	Question last
	String[]words = {"car=","cart","carp","cart"};
	Arrays.sort(words);
	String str1= words[0];
	String str2 = words[words.length-1];
	int index = 0;
	while(index<str1.length()) {
		if(str1.charAt(index)==str2.charAt(index)) {
			index++;
		}else {
			break;
		}
	}
	if(index==0) {
		System.out.println("No words in common");
	}else {
		System.out.println(str1.substring(0, index));
	}
	
//	//Question 1 : JAVA1234KK4
//	String s  ="JAVA12M34KK4";
//	int sum = 0;
//	String res = "0";
//	int temp=0;
//	for(int i=0;i<s.length();i++) {
//		System.out.print(s.charAt(i)+" ");
//		char data = s.charAt(i);
//		if(Character.isDigit(data)) {
//			res+=s.charAt(i);
//			
//		}else {
//			temp = Integer.parseInt(res);
//			sum+=temp;
//			res = "0";
//		}
//		System.out.println(sum+Integer.parseInt(res));
//		
//		
//	}
//	System.out.println(sum);
	
	
	
//	String []words = {"car","carnation","rajat","carpool"};
//	String str1 = words[0];
//	String longest="";
//	boolean isValid = true;
//	int index = 0;
//	while(isValid) {
//		String check = longest + str1.charAt(index);
//		for(int i=1;i<=str1.length()-1;i++) {
//			
//			if(words[i].startsWith(check)) {
//				
//			}
//			else {
//				isValid = false;
//				break;
//			}
//		}
//		index++;
//		if(isValid)longest=check;
//			
//	}
//	System.out.println(longest);

}


}
