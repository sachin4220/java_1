package day3;

public class testAs {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
