package day3;

public class UnderAgeException extends Exception{
	UnderAgeException (String message){
		super(message);
	}
}


