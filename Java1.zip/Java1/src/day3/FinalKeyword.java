package day3;

class UserM{
	final String schoolName = "ABC School";
}
final class ExamA{
	int examCodeA=101;
}
class ExamB extends ExamA{
	
}
class TestP{
	final void hello() {
		System.out.println("Hello");
	}
}
class TestQ extends TestP{
	void hello() {
		System.out.println("Hello from final function");
	}
}






public class FinalKeyword {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
