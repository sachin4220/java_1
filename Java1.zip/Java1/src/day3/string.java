package day3;

public class string {

	public static void main(String[] args) {
//		String str1= "hello ";
//		String str2= "World";
//		String str3= str1.concat(str2);
//		System.out.println(str3);
		// TODO Auto-generated method stub
		
		String str5 = "today is friday";
//		String str4 = "friday is today";
//		System.out.println(str.charAt(0));
//		System.out.println(str.indexOf('o'));
//		
		
//		String[]words = str5.split("\s");
//		String ans="";
//		String word="";
//		for(int i=words.length-1;i>=0;i--) {
//			ans=ans+words[i]+" ";
//		}
//		System.out.println(ans.trim());
//	}
//	
//	
		
	

}
