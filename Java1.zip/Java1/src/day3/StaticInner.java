package day3;

public class StaticInner {
public static void main(String[] args) {
	UserK user= new UserK();
	user.name="Kushagra";
	user.age = 24;
	
	
	UserK.Address address = new UserK.Address();
	address.city = "Lucknw";
	address.state = "UP";
	address.country = "IN";
	
	UserK.Favorite fav = new UserK.Favorite();
	fav.color = "red";
	fav.food ="Chole Bhature";
	UserK.Favorite.car ="BMW";
}
}
