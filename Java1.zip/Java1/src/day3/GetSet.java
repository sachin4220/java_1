package day3;

class Employee{
	int empId;
	String empName;
	float empSalary;
	Employee(int empId,String empName,float empSalary){
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
		
		
	}
	String getName() {
		return empName;
		
	}
	void setEmpName(String empName) {
		this.empName = empName;
	}
	public float getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(float empSalary) {
		this.empSalary = empSalary;
	}
}

public class GetSet {
public static void main(String[] args) {
	Employee e1 = new Employee(85010215,"Kushagra",2300.50F);
	e1.setEmpName("AadiKush");
	System.out.println(e1.getName());
}
	

}
