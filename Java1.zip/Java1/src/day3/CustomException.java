package day3;

public class CustomException {
	
	
	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		super.finalize();
	}

	static void checkAge(int age) throws Exception{
		
		if(age<18) {
			throw new UnderAgeException("You are still not 18");
		}
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		try {
			checkAge(17);
		}
		catch(UnderAgeException ex) {
			System.out.println("You have an exception "+ex.getMessage());
		}
	}

}
