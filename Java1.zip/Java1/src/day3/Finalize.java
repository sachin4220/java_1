package day3;



public class Finalize {
	
	@Override
	protetced void finalize() throws Throwable{
		System.out.println("FInalise is called");
	}
	
public static void main(String[] args) {
	Finalize obj2 = new Program10_Finalize();
	String obj2 = new String();
	obj2 = null;
	System.gc();
	System.out.println("Hello");
}
}
