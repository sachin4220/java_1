package Selenium_Day2;

import org.openqa.selenium.chrome.*;

import java.util.List;

import org.openqa.selenium.*;


public class Program1_Heading {
public static void main(String[] args)throws Exception {
	ChromeDriver driver = new ChromeDriver();
//	driver.get("https://www.engineerdiaries.com/selenium");
//	driver.get("https://www.spicejet.com/");
//	Thread.sleep(5000);	
//	Question1 : Print Heading
//	List<WebElement>headlist = driver.findElements(By.xpath("//table//th"));
//	System.out.println(headlist.size());
//	for(WebElement data : headlist) {
//		System.out.print(data.getText()+" ");
//	}
//	driver.quit();
//	
////	//Question2 : emp103 row print
//	List<WebElement>table = driver.findElements(By.xpath("//table//tr[3]/td"));
//	for(WebElement tb : table) {
//		System.out.print(tb.getText()+" ");
//	}
//	driver.quit();
////	//Question3: 
//	List<WebElement>table2 = driver.findElements(By.xpath("//table/tbody/tr/td[4]"));
//	for(WebElement tb1 : table2) {
//		System.out.print(tb1.getText()+" ");
//	}	
//	driver.quit();
//	//Question 4 :footer links print
//	List<WebElement>table3 = driver.findElements(By.xpath("//footer//a"));
//	for(WebElement tb2 : table3) {
//		System.out.print(tb2.getText()+" ");
//	}
//	driver.quit();
	
	
	//Spice jet pune to chennai
//	
//	driver.findElement(By.xpath("//*[text()='FROM']")).click();
//	Thread.sleep(2000);
//	driver.findElement(By.xpath("//input[@type='text']")).sendKeys("pun");
//	Thread.sleep(2000);
//	driver.findElement(By.xpath("//*[text()='MAA']")).click();
//	
//	
//	List<WebElement> to  = driver.findElements(By.xpath("//*[@data-testid='search-destination-code' and text()='MAA']"));
//	System.out.println(from + "->" + to);
//	driver.quit();
	
	driver.get("https://www.oyorooms.com/");
	Thread.sleep(3000);
	driver.findElement(By.xpath("//*[contains(@class,'datePickerDesktop')]")).click();
	Thread.sleep(2000);
	WebElement arrow = driver.findElements(By.xpath("//*[contains(@class,'DateRangePicker__PaginationArrow--next')]")).click();
	for(int i=1;i<=4;i++) {
		arrow.click();
		Thread.sleep(2000);
	}
	
	
	
	//oyo rooms 3 to 6
	
}
}
