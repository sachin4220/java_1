package Selenium_Day2;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.*;
public class Program2_Frame {
public static void main(String[] args)throws Exception {
	
	ChromeDriver driver = new ChromeDriver();
	driver.get("https://engineerdiaries.com/selenium");
	Thread.sleep(3000);
//	WebElement frameTag = driver.findElement(By.xpath("//iframe[@data-testid='custom-frame']"));
//	driver.switchTo().frame(frameTag); //because it is a web page thats why switch to is used
//	driver.findElement(By.name("username")).sendKeys("Hello Kushagra"); //because it is a web page thats why switch to is used
//	
//	driver.findElement(By.name("file")).sendKeys("C:\\Users\\Sachin.7.Yadav\\Desktop\\test.txt");
//	driver.findElement(By.id("date")).sendKeys("15-07-2026");
	
//	driver.findElement(By.id)
//	driver.switchTo().defaultContent();
	WebElement frameTag = driver.findElement(By.xpath("//iframe[@id='outer']"));
	driver.switchTo().frame(frameTag);
	driver.findElement(By.id("input1")).sendKeys("one");
	WebElement frameTag2 = driver.findElement(By.id("inner"));
//	iframe[@data-testid='inner-textbox']
	driver.switchTo().frame(frameTag2);
	driver.findElement(By.id("input2")).sendKeys("two");
	driver.switchTo().parentFrame();
	driver.findElement(By.id("input1")).sendKeys("three");
	
	
	//driver.switchTo().parentframe
	}
}
