package Selenium_Day3;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;



public class Program_GetMethod {
	public static void main(String[] args)throws Exception {
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://engineerdiaries.com/selenium");
		Thread.sleep(3000);
		
		
		WebElement inputBox = driver.findElement(By.id("input_text"));
		System.out.println(inputBox.getAccessibleName());
		System.out.println(inputBox.getAriaRole());
		System.out.println(inputBox.getAttribute("placeholder"));
		System.out.println(inputBox.getCssValue("font-size"));
	}

}
