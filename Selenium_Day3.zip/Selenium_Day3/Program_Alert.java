package Selenium_Day3;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.Alert;

public class Program_Alert {
	public static void main(String[] args) throws Exception{
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://engineerdiaries.com/selenium");
		Thread.sleep(3000);
////		To get alert button 
//		//driver.findElement(By.id("alert")).click();
////		Alert alertbtn = driver.switchTo().alert();
////		System.out.println(alertbtn.getText());
//		
//		
//		//To get confirm button
//		driver.findElement(By.id("confirm")).click();
//		Thread.sleep(2000);
//		Alert alertbtn = driver.switchTo().alert();
//		System.out.println(alertbtn.getText());
////		alertbtn.accept();
//		alertbtn.dismiss();
//		
		driver.findElement(By.id("prompt")).click();
		Alert alertbtn = driver.switchTo().alert();
		alertbtn.sendKeys("JAVA");
		Thread.sleep(2000);
		alertbtn.accept();
		
		driver.quit();		
		
	}
	

}
