package Selenium_Day3;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;



public class Program_LinkValidation {
	public static void main(String[] args)throws Exception {
		ChromeDriver driver  = new ChromeDriver();
		driver.get("https://engineerdiaries.com/selenium");
		Thread.sleep(4000);
		List<WebElement>links =driver.findElements(By.xpath("//footer//a"));
		
		for(WebElement link :links) {
			try {
				String url = link.getAttribute("href");
				
				HttpURLConnection conn = (HttpURLConnection) new URL(link.getAttribute("href")).openConnection();
				conn.setRequestMethod("GET");
				System.out.println(conn.getResponseCode());
				if(conn.getResponseCode()==404) {
					System.out.println("Testing is not working");
				}else {
					System.out.println("Testing is working");
				}
			}catch(Exception e) {
				
			}
		}
		
		
		
		
		
		
//		HttpURLConnection conn = (HttpURLConnection) new URL("https://www.tutorialspoint.com/compilerhhjjh/index.html").openConnection();
//		conn.setRequestMethod("GET");
//		System.out.println(conn.getResponseCode());
//		if(conn.getResponseCode()==404) {
//			System.out.println("Testing is not working");
//		}else {
//			System.out.println("Testing is working");
//		}
		
		
	}}