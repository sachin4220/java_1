package Selenium_Day3;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;



public class Program_WindowHandling {
	public static void main(String[] args)throws Exception {
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://engineerdiaries.com/selenium");
		Thread.sleep(3000);
		
		String homepage = driver.getWindowHandle();
		driver.findElement(By.xpath("//*[text()='Open This Page']")).click();
		Thread.sleep(2000);
		
		driver.switchTo().window(homepage);
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[text()='Open Google']")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//*[text()='Open Facebook']")).click();
		Thread.sleep(2000);
		
		driver.switchTo().window(homepage);
		Thread.sleep(2000);
		
		Set<String>windows = driver.getWindowHandles();
		for(String win:windows) {
			driver.switchTo().window(win);
			Thread.sleep(2000);
			if(driver.getTitle().contains("Google"))
				driver.close();
		}
       
		
		
	}}