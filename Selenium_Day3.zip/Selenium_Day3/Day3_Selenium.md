1.Dropdown handling
2.