package Selenium_Day3;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;



public class Program_Actions {
	public static void main(String[] args)throws Exception {
		ChromeDriver driver = new ChromeDriver();
		driver.get("https://engineerdiaries.com/selenium");
		Thread.sleep(3000);
		
//		WebElement hover = driver.findElement(By.xpath("//*[@data-testid='hover-box']"));
		Actions action = new Actions(driver);//action class ko driver control dena pdta hai
//		action.moveToElement(hover).build().perform();
//		Thread.sleep(4000);
//		
//		//Right click
//		WebElement rightClick = driver.findElement(By.xpath("//*[@data-testid='right-click-box']"));
//		action.contextClick(rightClick).perform();
//		Thread.sleep(3000);
//		
//		//Doubleclick
//		WebElement doubleClickBtn = driver.findElement(By.xpath("//*[@data-testid='double-click-box']"));
//		action.doubleClick(doubleClickBtn).perform();
//		driver.quit();
//		
//		//Keyboard interaction
//		
//		WebElement inputBox = driver.findElement(By.id("input_text"));
//		inputBox.clear();
//		action.keyDown(Keys.SHIFT).perform();
//		inputBox.sendKeys("java");
//		
//		//Scroll
//		WebElement fancyBtn = driver.findElement(By.xpath("//*[@data-testid='fancy-button']"));
//		action.scrollToElement(fancyBtn).perform();
//		
		//Range
//		driver.findElement(By.className("thumb-left")).sendKeys("40");
//		WebElement left = driver.findElement(By.className("thumb-left"));
//		WebElement right = driver.findElement(By.className("thumb-right"));
//		
//		int num =1;
//		while(num<=20) {
//			left.sendKeys(Keys.ARROW_RIGHT);
//			num++;
//		}
//		int k = 1;
//		while(k<=20) {
//			right.sendKeys(Keys.ARROW_LEFT);
//			k++;
//		}

		WebElement drag = driver.findElement(By.xpath("//*[@id='draggable']"));
		WebElement drop = driver.findElement(By.xpath("//*[contains(text(),'Drop here')]"));
		
		action.dragAndDrop(drag, drop).perform();
       
		
		
	}}