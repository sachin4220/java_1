package Selenium_Day3;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Program_Dropdown {
public static void main(String[] args) throws InterruptedException {
	ChromeDriver driver = new ChromeDriver();
	driver.get("https://engineerdiaries.com/selenium");
	Thread.sleep(4000);
	
	//This is a method to get title
	System.out.println(driver.getTitle());
	
	WebElement countryTag = driver.findElement(By.id("country"));
	Select selectCountry = new Select(countryTag);
	selectCountry.selectByIndex(8);
	Thread.sleep(3000);
	//method 2
	
	selectCountry.selectByValue("india");
	Thread.sleep(3000);
	selectCountry.selectByVisibleText("Russia");
	
}
}
