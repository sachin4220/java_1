package Selenium_Day3;

import java.util.Set;

import org.openqa.selenium.Cookie;
import org.openqa.selenium.chrome.ChromeDriver;

public class Program_Cookie {
	public static void main(String[] args) throws Exception {
		ChromeDriver driver = new ChromeDriver();
		Thread.sleep(3000);
		driver.get("https://www.engineerdiaries.com/selenium");
		Thread.sleep(8000);
		Cookie c1 = new Cookie("keyA","valueA");
		driver.manage().addCookie(c1);
		Set<Cookie>cookies=driver.manage().getCookies();
		for(Cookie cook: cookies) {
			System.out.println(cook.getName()+":"+cook.getValue());
		}
		driver.manage().deleteCookie(c1);
		driver.manage().deleteCookieNamed("gfg_theme");
		System.out.println("************");
		cookies=driver.manage().getCookies();
		for(Cookie c :cookies ) {
			System.out.println(c.getName()+":"+c.getValue());
		}
	}

}
