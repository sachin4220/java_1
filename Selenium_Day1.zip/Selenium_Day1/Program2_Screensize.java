package Selenium_Day1;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.*;

public class Program2_Screensize {
public static void main(String[] args)throws Exception {
	ChromeDriver driver = new ChromeDriver();
	Thread.sleep(2000);
	driver.manage().window().maximize();
	
	driver.get("https://www.engineerdiaries.com/selenium");
	Thread.sleep(2000);
	driver.manage().window().minimize();
	Thread.sleep(2000);
	
	driver.manage().window().setSize(new Dimension(500,900));
	Thread.sleep(2000);
	driver.quit();
	
}
}
