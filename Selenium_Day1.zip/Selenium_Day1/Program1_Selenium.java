package Selenium_Day1;

import org.openqa.selenium.chrome.*;
import org.openqa.selenium.*;


public class Program1_Selenium {
public static void main(String[] args)throws Exception {
	ChromeDriver driver = new ChromeDriver();
	Thread.sleep(3000);
	driver.manage().window().maximize();
	Thread.sleep(2000);
	driver.get("http://www.google.com");
	driver.navigate().back();

	Thread.sleep(3000);
	driver.get("http://www.wikipedia.com");
	driver.navigate().back();
	Thread.sleep(3000);
	driver.get("http://www.yahoo.com");
	driver.navigate().refresh();

	Thread.sleep(3000);
	driver.get("http://www.geeksforgeeks.com");

	Thread.sleep(3000);
	driver.get("http://www.iengage.com/ess2/login");
	driver.quit();
}
}
