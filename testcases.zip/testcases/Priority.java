package testcases;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Priority {
	@Test(priority=0)
	void methodC() {
		System.out.println("METHOD C");
	}
	@Test(priority= 4)
	void methodA() {
		System.out.println("METHOD A");
	}
	@Test(priority= 4)
	void methodB() {
		System.out.println("METHOD B");
	}

}
