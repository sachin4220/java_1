package testcases;

import org.testng.Assert;
import org.testng.annotations.*;
import org.testng.asserts.SoftAssert;

public class Program_Example {
	@Test
	void login() {
		int num = 10/0;
		System.out.println("METHOD C");
	}
	@Test(dependsOnMethods= {"login"})
	void logout() {
		System.out.println("METHOD A");
	}
	@Test(enabled=false)
	void forgetPassword() {
		System.out.println("METHOD B");
	}
	@Test(timeOut = 5000)
		void reLoad() throws Exception{
			Thread.sleep(7000);
			System.out.println("reLoad");
		}
	}


