package testcases;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Program_ParallelTest {
@Test
void methodA()throws Exception{
	ChromeDriver driver = new ChromeDriver();
	Thread.sleep(2000);
	driver.manage().window().maximize();
	driver.get("https://www.engineerdiaries.com/selenium");
	Thread.sleep(2000);
	driver.quit();
}
@Test
void methodB()throws Exception{
	ChromeDriver driver = new ChromeDriver();
	Thread.sleep(2000);
	driver.manage().window().maximize();
	driver.get("https://www.geeksforgeeks/");
	Thread.sleep(2000);
	driver.quit();
}
}
