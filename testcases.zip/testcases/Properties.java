package testcases;
import java.util.*;
import java.io.*;

public class Properties {
	public static void main(String[] args)throws Exception {
		Properties prop = new Properties();
		prop.load(new FileInputStream ("C:\\Users\\Sachin.7.Yadav\\eclipse-workspace\\Java1\\src\\testcases\\data.properties"));
		System.out.println(prop.getProperty("url"));
	}

}
