package testcases;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class CommentTest {
	@Test
	void commentA() {
		try {
			int num=10/0;
			System.out.println("COMMENT A");
		}catch(Exception e) {
		
		}
		
	}
	@Test
	void commentB() {
		boolean value=false;
//		Assert.assertTrue(value); Hard Assertion
		SoftAssert soft = new SoftAssert();
		soft.assertTrue(value);
		System.out.println("COMMENT B");
		soft.assertAll();
	}
	
	

}
