package testcases;

import org.testng.annotations.Test;

public class LoginTest {
 @Test(retryAnalyzer=Rerun.class)
 void payment() {
	System.out.println("Test case started");
	int num = 10/0;
}
}
